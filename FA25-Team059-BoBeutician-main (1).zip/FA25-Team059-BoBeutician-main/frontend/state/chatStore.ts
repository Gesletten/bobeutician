// Optional zustand store placeholder
export type Message = { id: number; text: string; role: 'user' | 'assistant' }

export const initialState: Message[] = []

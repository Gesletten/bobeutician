export const colors = {
  background_main: '#F6F1F0',
  background_secondary: '#f2e4e2cc',
  components: '#DEA193',
  active_test : '#7e473a',
  text_main: '#260000',
  text_secondaty: '#FFFFFF',
}
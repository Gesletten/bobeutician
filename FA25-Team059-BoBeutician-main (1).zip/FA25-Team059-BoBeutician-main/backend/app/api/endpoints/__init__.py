"""API endpoints package."""

__all__ = [
	"chat",
	"qa",
	"ingredients",
	"products",
]

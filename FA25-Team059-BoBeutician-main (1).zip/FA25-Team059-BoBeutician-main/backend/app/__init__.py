"""Backend application package for BoBeutician."""

__all__ = [
    "main",
]
